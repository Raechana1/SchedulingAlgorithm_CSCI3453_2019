#include <stdio.h>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>
#include <sstream>
#include <cstdlib>
#include <algorithm>

using namespace std;

struct process{
	int pid = 0;
	int arrival = 0;
	int burst = 0;
	int burst2 = 0; //for SRTF
	int finish = 0;
	int wait = 0;
	int turn_around = 0;
	int num_of_context = 0;
}p;

string input_file;
string line;
string schedule_type = "";
int quantum_size;
vector<process> processes;


//finds the average times and 
//number of context switches
void avgtimes(){
	int avgburst = 0;
	int avgwait = 0;
	int avgturn = 0;
	int totalcontext = 0;
	int denummerator = processes.size();
	for(int i = 0; i < denummerator; ++i){
		avgburst += processes[i].burst;
		avgwait += processes[i].wait;
		avgturn += processes[i].turn_around;
		totalcontext += processes[i].num_of_context;
	}
	
	cout << "Average CPU burst time = " << (float)avgburst/(float)denummerator << " ms" << endl;
	cout << "Average waiting time = " << (float)avgwait/(float)denummerator << " ms" << endl;
	cout << "Average turn around time = " << (float)avgturn/(float)denummerator << " ms" << endl;
	cout << "Total No. of Context Switching Performed = " << totalcontext/(float)denummerator << '\n' << endl;
}

//Implements the first come first serve scheduling
void FCFS(){
	//calculate waiting time
	for(int i = 1; i < processes.size(); ++i){
		int temp = processes[i-1].burst + processes[i-1].wait;
		processes[i].wait = temp - (processes[i].arrival - processes[i-1].arrival);
	}
	//calculate turn around time
	for(int i = 0; i < processes.size(); ++i){
		processes[i].turn_around = processes[i].burst + processes[i].wait;
	}
	//calculate finish time
	for(int i = 0; i < processes.size(); ++i){
		processes[i].finish = processes[i].turn_around + processes[i].arrival;
	}
	
	cout << "************************************************************" << endl;
	cout << "**************Scheduling Algorithm: FCFS *******************" << endl;
	cout << "************************************************************" << '\n' << endl;

	cout << "Gnatt Chart" << endl;
	cout << "**********************************" << '\n' << endl;

	cout << "pid\tarrival\tCPU-\tfinish\twaiting\tturn\tNo. of" << endl;
	cout << "\t\tburst\t\ttime\taround\tContext" << endl;
	for(int i = 0; i < processes.size(); ++i){
		cout << processes[i].pid << '\t' << processes[i].arrival << '\t' << processes[i].burst 
			<< '\t' << processes[i].finish << '\t' << processes[i].wait << '\t' 
			<< processes[i].turn_around << '\t' << processes[i].num_of_context << endl;
	}
	avgtimes();
}

//Implements the round robin scheduling
void Round_Robin(){
	cout << "************************************************************" << endl;
	cout << "***********Scheduling Algorithm: Round Robin ***************" << endl;
	cout << "************************************************************" << '\n' << endl;

	cout << "Gnatt Chart" << endl;
	cout << "**********************************" << '\n' << endl;

	cout << "pid\tarrival\tCPU-\tfinish\twaiting\tturn\tNo. of" << endl;
	cout << "\t\tburst\t\ttime\taround\tContext" << endl;

	avgtimes();
}

//Implements the shortest remaining tasking first scheduling
void SRTF(){
	int i = 0, j = 0, pcompare = 0;
	int size = processes.size();
	//makes a copy of the burst time
	for(int k = 0; k < size; ++k){
		processes[k].burst2 = processes[k].burst;
	}
	
	bool compare_arrival(process a, process b){
		return a.arrival < b.arrival;
	}
	
	bool compare_burst(process a, process b){
		return a.burst < b.burst;
	
	sort(processes, processes + size, compare_arrival);
	
	while(pcompare < size){
		for(j = 0; j < size; ++j){
			if(processes[j].arrival > i)
				break;
		}
		sort(processes, processes + size, compare_burst);
		if(j > 0){
			for(j = 0; j < size; ++j){
				if(processes[j].burst != 0;
					break;
			}
			if(processes[j].arrival > i){
				i = processes[j].arrival;
			}
			processes[j].finish = i + 1;
			processes[j].burst--;
		}
		i++;
		pcompare = 0;
		for(j = 0; j < size; ++j){
			if(processes[j].burst == 0)
				pcompare++;
		}
	}
	

	//calculates turn around time
	for(int i = 0; i < size; ++i){
		processes[i].turn_around = processes[i].finish + processes[i].arrival;
	}
	
		//calculate wait time
	for(int i = 0; i < size; ++i){
		processes[i].wait = processes[i].turn_around - processes[i].burst2;
	
	cout << "************************************************************" << endl;
	cout << "**************Scheduling Algorithm: SRTF *******************" << endl;
	cout << "************************************************************" << '\n' << endl;

	cout << "Gnatt Chart" << endl;
	cout << "**********************************" << '\n' << endl;

	cout << "pid\tarrival\tCPU-\tfinish\twaiting\tturn\tNo. of" << endl;
	cout << "\t\tburst\t\ttime\taround\tContext" << endl;
	
	avgtimes();
}



int main(int argc, char**argv){
	//sets the input file, schedule_type and quantum_size if RR type
	input_file = argv[1];
	schedule_type = argv[2];
	if(schedule_type == "RR" && argc == 4){
		quantum_size = atoi(argv[3]);
	}
	
	
	//opens and saves the input file in vector of processes
	//acts as the PCB
	ifstream ifile(input_file);
	if (ifile.is_open()){
		while(getline(ifile, line)){
			stringstream iss(line);
			iss >> p.pid >> p.arrival >> p.burst;
			processes.push_back(p);
		}
	}

	//closes file
	ifile.close();
	
	if(schedule_type == "FCFS"){
		FCFS();
	}
	else if(schedule_type == "SRTF"){
		SRTF();
	}
	else if(schedule_type == "RR" && argc == 4){
		Round_Robin();
	}
	else{
		cout << "Error: Incorrect CPU Scheduling Algorithm" << endl;
	}

	
}